﻿param([switch]$NoUI,[switch]$IsolatedTest,[string]$Destination,[string]$DesktopDirectory,[switch]$ValidateOnly)
$ErrorActionPreference='Stop'
$source=Join-Path $PSScriptRoot 'CartelleColorate'
function Test-NovaPackage {
    $manifest=Join-Path $source 'MANIFEST-SHA256.txt'
    if(![IO.File]::Exists($manifest)){throw 'Estrai tutto lo ZIP prima di installare Nova.'}
    $script:novaFiles=@()
    foreach($line in [IO.File]::ReadAllLines($manifest)){
        if(!$line){continue}
        if($line -notmatch '^([a-f0-9]{64})  ([A-Za-z0-9_.-]+)$'){throw 'Manifest non valido.'}
        $digest=$matches[1];$name=$matches[2];$file=Join-Path $source $name
        if(![IO.File]::Exists($file) -or (Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant() -ne $digest){throw ('File mancante o modificato: '+$name)}
        $script:novaFiles+=$name
    }
    foreach($required in @('CartelleColorate.ps1','Interfaccia.ps1','NativeLibraries.ps1','Nova-Native.ps1','FolderShell.cs','DesktopPicker.cs','Avvio.vbs','Avvio.ps1','Rapido.vbs')){if($required -notin $script:novaFiles){throw ('File mancante: '+$required)}}
    if(!$IsolatedTest -and !$ValidateOnly){
        & (Join-Path $env:SystemRoot 'System32/cscript.exe') //B //Nologo (Join-Path $source 'Verifica.vbs')
        if($LASTEXITCODE -ne 0){throw 'Windows Script Host non disponibile.'}
    }
}
function Set-NovaInstallStatus([string]$Message,[int]$Progress) {
    if($script:installerStatus){$script:installerStatus.Text=$Message;$script:installerProgress.Value=$Progress;$script:installerWindow.Dispatcher.Invoke([Action]{},[Windows.Threading.DispatcherPriority]::Render)}
}
function Install-Nova {
    Test-NovaPackage
    if($IsolatedTest){
        if(!$NoUI -or !$Destination -or !$DesktopDirectory){throw 'Il test isolato richiede percorsi espliciti e NoUI.'}
        $dest=[IO.Path]::GetFullPath($Destination);$desktop=[IO.Path]::GetFullPath($DesktopDirectory)
    }else{$dest=Join-Path $env:LOCALAPPDATA 'CartelleColorateNova';$desktop=[Environment]::GetFolderPath('DesktopDirectory')}
    $runtime=Join-Path $dest 'DatiNova/CartelleColorate';$dataBase=Split-Path $runtime -Parent
    [IO.Directory]::CreateDirectory($runtime)|Out-Null;[IO.Directory]::CreateDirectory($desktop)|Out-Null
    foreach($name in @('FolderShell.dll','DesktopPicker.dll')){
        $existing=Join-Path $runtime $name
        if([IO.File]::Exists($existing)){
            try{$handle=[IO.File]::Open($existing,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);$handle.Dispose()}catch{throw 'Chiudi Nova prima di aggiornare, poi premi Riprova.'}
        }
    }
    Set-NovaInstallStatus 'Copia dellʼapplicazione…' 20
    foreach($name in $script:novaFiles){
        $from=Join-Path $source $name;$to=Join-Path $runtime $name
        if([IO.Path]::GetExtension($name) -eq '.ps1'){
            $text=[IO.File]::ReadAllText($from).Replace('Directory\shell\CartelleColorate','Directory\shell\CartelleColorateNova').Replace('CartelleColorate.Menu','CartelleColorateNova.Menu').Replace('CartelleColorate.Presets','CartelleColorateNova.Presets')
            if($name -eq 'CartelleColorate.ps1'){$text=$text.Replace("-Value (T 'change')","-Value ((T 'change')+' · Nova')")}
            [IO.File]::WriteAllText($to,$text,[Text.UTF8Encoding]::new($true))
        }else{Copy-Item -LiteralPath $from -Destination $to -Force}
    }
    $settings=Join-Path $runtime 'impostazioni.json'
    if(![IO.File]::Exists($settings)){[IO.File]::WriteAllText($settings,'{"language":"it","theme":"Dark"}',[Text.UTF8Encoding]::new($true))}
    Set-NovaInstallStatus 'Preparazione delle icone e della pipetta…' 45
    & powershell.exe -NoProfile -NonInteractive -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File (Join-Path $runtime 'Nova-Native.ps1')
    if($LASTEXITCODE -ne 0){throw 'Preparazione delle librerie non riuscita.'}
    $environment=@'
SetNovaEnvironment
Sub SetNovaEnvironment()
    shell.Environment("PROCESS")("LOCALAPPDATA") = files.GetParentFolderName(root)
    shell.Environment("PROCESS")("CC_PRO_PREVIEW") = ""
    shell.Environment("PROCESS")("PSModulePath") = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\Modules")
End Sub
'@
    foreach($name in @('Avvio.vbs','Rapido.vbs')){
        $file=Join-Path $runtime $name;$text=[IO.File]::ReadAllText($file)
        $needle=if($name -eq 'Avvio.vbs'){'root = files.GetParentFolderName(WScript.ScriptFullName)'}else{'root=files.GetParentFolderName(WScript.ScriptFullName)'}
        if(!$text.Contains($needle)){throw 'Avvio del pacchetto non riconosciuto.'}
        [IO.File]::WriteAllText($file,$text.Replace($needle,$needle+[Environment]::NewLine+$environment),[Text.Encoding]::ASCII)
    }
    $launcher=@'
Option Explicit
Dim shell, files, base, folder, command
Set shell=CreateObject("WScript.Shell")
Set files=CreateObject("Scripting.FileSystemObject")
base=files.GetParentFolderName(WScript.ScriptFullName)
folder=base & "\La mia galassia"
If Not files.FolderExists(folder) Then files.CreateFolder folder
command=Chr(34) & shell.ExpandEnvironmentStrings("%SystemRoot%\System32\wscript.exe") & Chr(34) & " " & Chr(34) & base & "\DatiNova\CartelleColorate\Avvio.vbs" & Chr(34) & " " & Chr(34) & folder & Chr(34)
shell.Run command,0,False
'@
    $entry=Join-Path $dest 'Avvia-Nova.vbs';[IO.File]::WriteAllText($entry,$launcher,[Text.Encoding]::ASCII)
    Set-NovaInstallStatus 'Creazione del collegamento sul desktop…' 70
    $wsh=New-Object -ComObject WScript.Shell;$shortcut=$wsh.CreateShortcut((Join-Path $desktop 'Nova Prism.lnk'))
    $shortcut.TargetPath=Join-Path $env:SystemRoot 'System32/wscript.exe';$shortcut.Arguments='"'+$entry+'"';$shortcut.WorkingDirectory=$dest;$shortcut.Description='Nova Prism — colori, immagini e stili gratuiti';$shortcut.IconLocation='shell32.dll,3';$shortcut.Save()
    if(!$IsolatedTest){
        Set-NovaInstallStatus 'Aggiunta al menu delle cartelle…' 85
        $priorData=$env:LOCALAPPDATA;$priorPreview=$env:CC_PRO_PREVIEW
        try{
            $env:LOCALAPPDATA=$dataBase;$env:CC_PRO_PREVIEW=''
            & powershell.exe -NoProfile -NonInteractive -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File (Join-Path $runtime 'CartelleColorate.ps1') -RefreshMenu
            if($LASTEXITCODE -ne 0){throw 'Impossibile aggiungere Nova al menu delle cartelle.'}
        }finally{$env:LOCALAPPDATA=$priorData;$env:CC_PRO_PREVIEW=$priorPreview}
    }
    Set-NovaInstallStatus 'Nova è pronta. Aprila dal desktop.' 100
    return $entry
}
if($ValidateOnly){Test-NovaPackage;Write-Output 'OK: installer Nova e manifest verificati.';exit}
if($NoUI){$installed=Install-Nova;Write-Output ('OK: Nova installata in '+$installed);exit}
Add-Type -AssemblyName PresentationFramework,PresentationCore,WindowsBase
[xml]$xaml=@'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" Title="Installa Nova Prism Prism" Width="520" Height="420" ResizeMode="NoResize" WindowStartupLocation="CenterScreen" Background="#090D1A" Foreground="#EFF4FF" FontFamily="Segoe UI" FontSize="13">
<Grid Margin="28"><Grid.RowDefinitions><RowDefinition Height="Auto"/><RowDefinition Height="*"/><RowDefinition Height="Auto"/></Grid.RowDefinitions><StackPanel><TextBlock Text="N O V A" FontSize="30" FontWeight="SemiBold"/><TextBlock Text="CARTELLECOLORATE" Foreground="#AAB9D6" FontSize="10" Margin="0,5,0,0"/></StackPanel><StackPanel Grid.Row="1" Margin="0,24,0,0"><TextBlock Text="Un nuovo spazio per le tue cartelle." FontSize="20" TextWrapping="Wrap"/><TextBlock Text="Installa Nova Prism con un collegamento sul desktop e una voce nel menu delle cartelle. Tutte le funzioni sono gratuite." Foreground="#B2C1DD" TextWrapping="Wrap" Margin="0,14,0,0"/><TextBlock Text="Installazione per il tuo utente. Studio rimane separata." Foreground="#91A5C7" TextWrapping="Wrap" FontSize="12" Margin="0,14,0,0"/><TextBlock x:Name="Status" Text="Pronta per lʼinstallazione." Margin="0,24,0,8" TextWrapping="Wrap"/><ProgressBar x:Name="Progress" Height="6" Maximum="100" Foreground="#80EFE2" Background="#202B45" BorderThickness="0"/></StackPanel><Button x:Name="Install" Grid.Row="2" Content="Installa Nova Prism →" Height="44" Margin="0,20,0,0" Foreground="#0A192A" FontWeight="SemiBold" BorderThickness="0"><Button.Background><LinearGradientBrush><GradientStop Color="#80EFE2" Offset="0"/><GradientStop Color="#A89BFF" Offset="1"/></LinearGradientBrush></Button.Background><Button.Template><ControlTemplate TargetType="Button"><Border Background="{TemplateBinding Background}" CornerRadius="14"><ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/></Border></ControlTemplate></Button.Template></Button></Grid>
</Window>
'@
$script:installerWindow=[Windows.Markup.XamlReader]::Load([Xml.XmlNodeReader]::new($xaml));$script:installerStatus=$script:installerWindow.FindName('Status');$script:installerProgress=$script:installerWindow.FindName('Progress');$install=$script:installerWindow.FindName('Install')
$install.Add_Click({param($sender,$eventArgs)
    if($script:installedNovaEntry){Start-Process -FilePath (Join-Path $env:SystemRoot 'System32/wscript.exe') -ArgumentList ('"'+$script:installedNovaEntry+'"') -WindowStyle Hidden;$script:installerWindow.Close();return}
    $sender.IsEnabled=$false
    try{$script:installedNovaEntry=Install-Nova;$sender.Content='Apri Nova →'}catch{$script:installerStatus.Text='Installazione non riuscita: '+$_.Exception.Message;$sender.Content='Riprova'}finally{$sender.IsEnabled=$true}
})
[void]$script:installerWindow.ShowDialog()
