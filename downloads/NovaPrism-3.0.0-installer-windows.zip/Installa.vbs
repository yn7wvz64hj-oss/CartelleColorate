Option Explicit
Dim shell, files, base, command
Set shell=CreateObject("WScript.Shell")
Set files=CreateObject("Scripting.FileSystemObject")
base=files.GetParentFolderName(WScript.ScriptFullName)
shell.Environment("PROCESS")("PSModulePath")=shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\Modules")
command=Chr(34) & shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe") & Chr(34) & " -NoProfile -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File " & Chr(34) & base & "\Setup-Nova.ps1" & Chr(34)
shell.Run command,0,True
