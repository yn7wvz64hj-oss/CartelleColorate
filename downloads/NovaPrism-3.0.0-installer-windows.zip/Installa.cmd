@echo off
wscript.exe //Nologo "%~dp0Installa.vbs"
