﻿Option Explicit
Dim shell, files, base, folder, command
Set shell = CreateObject("WScript.Shell")
Set files = CreateObject("Scripting.FileSystemObject")
base = files.GetParentFolderName(WScript.ScriptFullName)
shell.Environment("PROCESS")("LOCALAPPDATA") = base & "\DatiNova"
shell.Environment("PROCESS")("CC_PRO_PREVIEW") = "1"
shell.Environment("PROCESS")("PSModulePath") = shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\Modules")
folder = base & "\La mia galassia"
If Not files.FolderExists(folder) Then files.CreateFolder folder
command = Chr(34) & shell.ExpandEnvironmentStrings("%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe") & Chr(34) & " -NoProfile -NonInteractive -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File " & Chr(34) & base & "\CartelleColorate\Nova-Avvio.ps1" & Chr(34) & " -Folder " & Chr(34) & folder & Chr(34)
shell.Run command, 0, False
