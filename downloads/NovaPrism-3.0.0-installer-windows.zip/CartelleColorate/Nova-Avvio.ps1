﻿param([string]$Folder,[switch]$NoConsoleTest,[switch]$SelfTest)
$ErrorActionPreference='Stop'
try {
    $privateData=Join-Path $env:LOCALAPPDATA 'CartelleColorate';[IO.Directory]::CreateDirectory($privateData)|Out-Null
    $settings=Join-Path $privateData 'impostazioni.json'
    if(![IO.File]::Exists($settings)){[IO.File]::WriteAllText($settings,'{"language":"it","theme":"Dark"}',[Text.UTF8Encoding]::new($true))}
    $blocked=$false
    foreach($name in @('FolderShell','DesktopPicker')){if(Get-Item -LiteralPath (Join-Path $PSScriptRoot ($name+'.dll')) -Stream Zone.Identifier -ErrorAction SilentlyContinue){$blocked=$true}}
    if($blocked){& powershell.exe -NoProfile -NonInteractive -STA -WindowStyle Hidden -ExecutionPolicy Bypass -File (Join-Path $PSScriptRoot 'Nova-Native.ps1');if($LASTEXITCODE -ne 0){throw 'Preparazione delle librerie non riuscita.'}}
    & (Join-Path $PSScriptRoot 'CartelleColorate.ps1') -Folder $Folder -Theme Dark -NoConsoleTest:$NoConsoleTest -SelfTest:$SelfTest
} catch {
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'nova-errore.log'),($_.ToString()+[Environment]::NewLine+$_.ScriptStackTrace),[Text.Encoding]::UTF8)
    if($NoConsoleTest){Write-Output $_;exit 1}
    Add-Type -AssemblyName System.Windows.Forms
    [Windows.Forms.MessageBox]::Show(('Nova non riesce ad avviarsi. Dettagli in nova-errore.log'+[Environment]::NewLine+$_.Exception.Message),'Nova Prism')|Out-Null
    exit 1
}
