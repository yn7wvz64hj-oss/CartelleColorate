﻿$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'NativeLibraries.ps1')
Install-NativeLibraries $PSScriptRoot $PSScriptRoot
